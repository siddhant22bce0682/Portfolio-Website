# Crack Climbing Carousel - CSS :has()

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/poZRVJG](https://codepen.io/josetxu/pen/poZRVJG).

Testing the :has() pseudo-class to change the image in a carousel.

I've also used a technique I've been wanting to try for a long time, using radio inputs to create a CSS-only image carousel, showing and hiding different radio inputs with each carousel movement. In the end I have freaked out a bit and I have also put some thumbnails.

Images from: <a href="https://cuadernodeescaladas.com/">cuadernodeescaladas.com </a>